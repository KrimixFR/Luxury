resource_manifest_version "77731fab-63ca-442c-a67b-abc70f28dfa5"

data_file "INTERIOR_PROXY_ORDER_FILE" "interiorproxies.meta"

files { "stream/interiorproxies.meta" }

this_is_a_map "yes"

